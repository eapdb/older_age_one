<?php
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "密碼雜湊為：$hash";
?>