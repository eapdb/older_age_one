<?php
require_once 'config.php';

// 清除用戶 session
unset($_SESSION['user_id']);
unset($_SESSION['username']);

// 重導向到首頁
redirect('index.php');
?>