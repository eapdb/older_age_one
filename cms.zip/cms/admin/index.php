<?php
require_once '../config.php';

// 檢查是否已登入
if (!is_admin_logged_in()) {
    redirect('login.php');
}

// 獲取統計資料
try {
    $total_articles_stmt = $pdo->query("SELECT COUNT(*) FROM articles");
    $total_articles = $total_articles_stmt->fetchColumn();
    
    $published_articles_stmt = $pdo->query("SELECT COUNT(*) FROM articles WHERE status = 'published'");
    $published_articles = $published_articles_stmt->fetchColumn();
    
    $total_users_stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $total_users = $total_users_stmt->fetchColumn();
    
    // 最新文章
    $recent_articles_stmt = $pdo->prepare("
        SELECT a.*, au.username as author_name 
        FROM articles a 
        LEFT JOIN admin_users au ON a.author_id = au.id 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ");
    $recent_articles_stmt->execute();
    $recent_articles = $recent_articles_stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = "獲取資料失敗: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>後台管理 - <?php echo htmlspecialchars(get_site_setting('site_title')); ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- 側邊欄 -->
    <div class="admin-sidebar">
        <h3>管理面板</h3>
        <ul>
            <li><a href="index.php">首頁</a></li>
            <li><a href="articles.php">文章管理</a></li>
            <li><a href="users.php">用戶管理</a></li>
            <li><a href="settings.php">網站設定</a></li>
            <li><a href="logout.php">登出</a></li>
        </ul>
    </div>

    <!-- 主要內容區 -->
    <div class="admin-content">
        <!-- 頂部導航 -->
        <div class="admin-header">
            <h1>後台管理首頁</h1>
            <div>
                歡迎, <?php echo htmlspecialchars($_SESSION['admin_username']); ?> |
                <a href="../index.php" target="_blank">查看前台</a> |
                <a href="logout.php">登出</a>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- 統計卡片 -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
            <div class="card">
                <div class="card-header">總文章數</div>
                <div class="card-body">
                    <h2 style="color: #3498db; margin: 0;"><?php echo $total_articles ?? 0; ?></h2>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">已發布文章</div>
                <div class="card-body">
                    <h2 style="color: #27ae60; margin: 0;"><?php echo $published_articles ?? 0; ?></h2>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">註冊用戶</div>
                <div class="card-body">
                    <h2 style="color: #f39c12; margin: 0;"><?php echo $total_users ?? 0; ?></h2>
                </div>
            </div>
        </div>

        <!-- 最新文章 -->
        <div class="card">
            <div class="card-header">
                最新文章
                <a href="articles.php" class="btn btn-sm" style="float: right;">查看全部</a>
            </div>
            <div class="card-body">
                <?php if (empty($recent_articles)): ?>
                    <p>目前沒有文章。</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>標題</th>
                                <th>作者</th>
                                <th>狀態</th>
                                <th>建立時間</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_articles as $article): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($article['title']); ?></td>
                                    <td><?php echo htmlspecialchars($article['author_name'] ?? '未知'); ?></td>
                                    <td>
                                        <span class="<?php echo $article['status'] == 'published' ? 'btn-success' : 'btn-warning'; ?> btn-sm">
                                            <?php echo $article['status'] == 'published' ? '已發布' : '草稿'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['created_at'])); ?></td>
                                    <td>
                                        <a href="article_edit.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-primary">編輯</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- 快速操作 -->
        <div class="card">
            <div class="card-header">快速操作</div>
            <div class="card-body">
                <a href="article_edit.php" class="btn btn-primary">新增文章</a>
                <a href="users.php" class="btn btn-success">管理用戶</a>
                <a href="settings.php" class="btn btn-warning">網站設定</a>
            </div>
        </div>
    </div>
</body>
</html>