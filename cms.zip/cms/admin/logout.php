<?php
require_once '../config.php';

// 清除管理員 session
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);

// 重導向到登入頁面
redirect('login.php');
?>