<?php
require_once '../config.php';

// 檢查是否已登入
if (!is_admin_logged_in()) {
    redirect('login.php');
}

$success = '';
$error = '';

// 處理刪除操作
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ?");
        $stmt->execute([$id]);
        $success = '文章已成功刪除';
    } catch (PDOException $e) {
        $error = '刪除失敗: ' . $e->getMessage();
    }
}

// 處理狀態更改
if (isset($_GET['action']) && $_GET['action'] == 'toggle_status' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("SELECT status FROM articles WHERE id = ?");
        $stmt->execute([$id]);
        $article = $stmt->fetch();
        
        if ($article) {
            $new_status = $article['status'] == 'published' ? 'draft' : 'published';
            $stmt = $pdo->prepare("UPDATE articles SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $id]);
            $success = '文章狀態已更新';
        }
    } catch (PDOException $e) {
        $error = '更新失敗: ' . $e->getMessage();
    }
}

// 獲取文章列表
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

try {
    // 獲取文章總數
    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM articles");
    $total_stmt->execute();
    $total_articles = $total_stmt->fetchColumn();
    $total_pages = ceil($total_articles / $limit);

    // 獲取當前頁文章
    $stmt = $pdo->prepare("
        SELECT a.*, au.username as author_name 
        FROM articles a 
        LEFT JOIN admin_users au ON a.author_id = au.id 
        ORDER BY a.created_at DESC 
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$limit, $offset]);
    $articles = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "獲取文章失敗: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文章管理 - 後台管理</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- 側邊欄 -->
    <div class="admin-sidebar">
        <h3>管理面板</h3>
        <ul>
            <li><a href="index.php">首頁</a></li>
            <li><a href="articles.php">文章管理</a></li>
            <li><a href="users.php">用戶管理</a></li>
            <li><a href="settings.php">網站設定</a></li>
            <li><a href="logout.php">登出</a></li>
        </ul>
    </div>

    <!-- 主要內容區 -->
    <div class="admin-content">
        <!-- 頂部導航 -->
        <div class="admin-header">
            <h1>文章管理</h1>
            <div>
                <a href="article_edit.php" class="btn btn-primary">新增文章</a>
            </div>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <!-- 文章列表 -->
        <div class="card">
            <div class="card-header">
                所有文章 (共 <?php echo $total_articles; ?> 篇)
            </div>
            <div class="card-body">
                <?php if (empty($articles)): ?>
                    <p>目前沒有文章。<a href="article_edit.php">立即新增第一篇文章</a></p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>標題</th>
                                <th>作者</th>
                                <th>狀態</th>
                                <th>建立時間</th>
                                <th>更新時間</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($articles as $article): ?>
                                <tr>
                                    <td><?php echo $article['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($article['title']); ?></strong>
                                        <br>
                                        <small style="color: #666;">
                                            <?php 
                                            $content = strip_tags($article['content']);
                                            echo htmlspecialchars(mb_substr($content, 0, 100)) . (mb_strlen($content) > 100 ? '...' : '');
                                            ?>
                                        </small>
                                    </td>
                                    <td><?php echo htmlspecialchars($article['author_name'] ?? '未知'); ?></td>
                                    <td>
                                        <span class="btn btn-sm <?php echo $article['status'] == 'published' ? 'btn-success' : 'btn-warning'; ?>">
                                            <?php echo $article['status'] == 'published' ? '已發布' : '草稿'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['created_at'])); ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($article['updated_at'])); ?></td>
                                    <td>
                                        <a href="../article.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-secondary" target="_blank">預覽</a>
                                        <a href="article_edit.php?id=<?php echo $article['id']; ?>" class="btn btn-sm btn-primary">編輯</a>
                                        <a href="?action=toggle_status&id=<?php echo $article['id']; ?>" 
                                           class="btn btn-sm <?php echo $article['status'] == 'published' ? 'btn-warning' : 'btn-success'; ?>"
                                           onclick="return confirm('確定要更改文章狀態嗎？')">
                                            <?php echo $article['status'] == 'published' ? '設為草稿' : '發布'; ?>
                                        </a>
                                        <a href="?action=delete&id=<?php echo $article['id']; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('確定要刪除這篇文章嗎？此操作無法復原！')">刪除</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- 分頁 -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>">上一頁</a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?page=<?php echo $i; ?>" <?php echo $i == $page ? 'class="active"' : ''; ?>>
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?>">下一頁</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // 確認刪除對話框
        function confirmDelete() {
            return confirm('確定要刪除這篇文章嗎？此操作無法復原！');
        }
    </script>
</body>
</html>