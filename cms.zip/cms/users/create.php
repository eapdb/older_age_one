<?php
// admin/users/create.php - 新增用戶頁面
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: ../login.php');
    exit;
}

require_once '../../config/database.php';
require_once '../../classes/User.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $status = $_POST['status'];

    // 驗證輸入
    if (empty($username)) {
        $errors[] = "用戶名不能為空";
    } elseif ($user->usernameExists($username)) {
        $errors[] = "用戶名已存在";
    }

    if (empty($email)) {
        $errors[] = "電子郵件不能為空";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "電子郵件格式不正確";
    } elseif ($user->emailExists($email)) {
        $errors[] = "電子郵件已存在";
    }

    if (empty($password)) {
        $errors[] = "密碼不能為空";
    } elseif (strlen($password) < 6) {
        $errors[] = "密碼至少需要6個字符";
    }

    if ($password !== $confirm_password) {
        $errors[] = "密碼確認不匹配";
    }

    if (empty($errors)) {
        $user->username = $username;
        $user->email = $email;
        $user->password = $password;
        $user->status = $status;

        if ($user->create()) {
            $success = true;
        } else {
            $errors[] = "創建用戶失敗";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>新增用戶 - CMS 後台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- 側邊欄 -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <h5>CMS 後台</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="../dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> 儀表板
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-users"></i> 用戶管理
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../articles/index.php">
                                <i class="fas fa-newspaper"></i> 文章管理
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../settings/index.php">
                                <i class="fas fa-cog"></i> 系統設定
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- 主要內容 -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">新增用戶</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="index.php" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> 返回列表
                        </a>
                    </div>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        用戶創建成功！
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <script>
                        setTimeout(function() {
                            window.location.href = 'index.php';
                        }, 2000);
                    </script>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-8">
                        <form method="POST" action="create.php">
                            <div class="mb-3">
                                <label for="username" class="form-label">用戶名 *</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">電子郵件 *</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">密碼 *</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <div class="form-text">密碼至少需要6個字符</div>
                            </div>

                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">確認密碼 *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>

                            <div class="mb-3">
                                <label for="status" class="form-label">狀態</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="active" <?php echo (isset($_POST['status']) && $_POST['status'] == 'active') ? 'selected' : ''; ?>>
                                        啟用
                                    </option>
                                    <option value="inactive" <?php echo (isset($_POST['status']) && $_POST['status'] == 'inactive') ? 'selected' : ''; ?>>
                                        停用
                                    </option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 創建用戶
                                </button>
                                <a href="index.php" class="btn btn-secondary">取消</a>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>