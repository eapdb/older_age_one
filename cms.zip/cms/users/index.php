// admin/users/index.php - 用戶列表頁面
session_start();

// 檢查管理員登入狀態（這裡簡化處理）
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once '../../config/database.php';
require_once '../../classes/User.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// 處理搜尋和分頁
$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// 獲取用戶列表
$users = $user->getAllUsers($limit, $offset, $search);
$total_users = $user->getTotalUsers($search);
$total_pages = ceil($total_users / $limit);

// 處理刪除操作
if (isset($_POST['delete_user'])) {
    $user->id = $_POST['user_id'];
    if ($user->delete()) {
        $message = "用戶刪除成功！";
    } else {
        $error = "刪除失敗！";
    }
    // 刷新頁面
    header("Location: index.php" . ($search ? "?search=" . urlencode($search) : ""));
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用戶管理 - CMS 後台</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- 側邊欄 -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <h5>CMS 後台</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="../dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> 儀表板
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-users"></i> 用戶管理
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../articles/index.php">
                                <i class="fas fa-newspaper"></i> 文章管理
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../settings/index.php">
                                <i class="fas fa-cog"></i> 系統設定
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- 主要內容 -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">編輯用戶</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="index.php" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-arrow-left"></i> 返回列表
                        </a>
                    </div>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        用戶更新成功！
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-8">
                        <form method="POST" action="edit.php?id=<?php echo $user_id; ?>">
                            <div class="mb-3">
                                <label for="username" class="form-label">用戶名 *</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($user_data['username']); ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">電子郵件 *</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo htmlspecialchars($user_data['email']); ?>"
                                       required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">新密碼</label>
                                <input type="password" class="form-control" id="password" name="password">
                                <div class="form-text">留空表示不更改密碼</div>
                            </div>

                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">確認新密碼</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            </div>

                            <div class="mb-3">
                                <label for="status" class="form-label">狀態</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="active" <?php echo ($user_data['status'] == 'active') ? 'selected' : ''; ?>>
                                        啟用
                                    </option>
                                    <option value="inactive" <?php echo ($user_data['status'] == 'inactive') ? 'selected' : ''; ?>>
                                        停用
                                    </option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 更新用戶
                                </button>
                                <a href="index.php" class="btn btn-secondary">取消</a>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h6>用戶資訊</h6>
                            </div>
                            <div class="card-body">
                                <p><strong>用戶ID:</strong> <?php echo $user_data['id']; ?></p>
                                <p><strong>註冊時間:</strong> <?php echo date('Y-m-d H:i:s', strtotime($user_data['created_at'])); ?></p>
                                <p><strong>最後更新:</strong> <?php echo date('Y-m-d H:i:s', strtotime($user_data['updated_at'])); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>